#!/bin/sh
ctags -R .
vim Makefile configure src/*
